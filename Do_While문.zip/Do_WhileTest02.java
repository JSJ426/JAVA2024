/* 작성일 : 4월 5일
 * 작성자 : 202295037 장석진
 * 설명 : 월을 입력 받습니다
 * */

import java.util.Scanner;

public class Do_WhileTest02 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		int month;
		
		do {
			System.out.print("월을 입력하시오(종료:0): ");
			month = stdIn.nextInt();
			
			switch(month)
			{
			// if(month == 3 || month ==4 || month ==5)
			case 3 : case 4 : case 5 :
				System.out.println("봄입니다."); break;
			case 6 : case 7 : case 8 :
				System.out.println("여름입니다."); break;
			case 9 : case 10 : case 11 :
			    System.out.println("가을입니다."); break;
			case 12 : case 1 : case 2 :
				System.out.println("겨울입니다."); break;
			case 0 :
				System.out.println("프로그램 종료 합니다."); break;
			default :
				System.out.println("해당 월은 없습니다."); break;
			
		    }
		}while(month != 0);

	}
}

