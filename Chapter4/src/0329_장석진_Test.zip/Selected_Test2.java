/*
 * 두 정수를 입력받아 두 수가 모두 짝수이면 더한 결과를 출력하고,
 * 그렇지 않고 두 수중 하나라도 홀수이면 몇 번째 입력한 수를 짝수로
 * 입력해야 하는지 출력하시오
 * 
 * [문제분석]
 *   짝수는 2로 나눈 나머지가 0이다.
 *   홀수는 2로 나눈 나머지가 1이다.(0이 아니다)
 *   
 *   두 정수가 필요하고, 각각 홀수인지 짝수인지 판단해야함.
 *   입력한 수 중 홀수가 있다면 몇번째 입력 수가 홀수인지 판단하고 짝수로 입력해야한다 출력해준다
 *   1.정수 두개가 필요하다
 *   2.각각의 정수를 홀수인지 짝수인지 판단한다(경우의 수는 4개)
 *   3.둘 다 짝수가 입력된 경우 두 수를 합한 값을 출력한다
 *   4.첫 번째 홀수, 두 번째 짝수가 입력된 경우 첫 번째에 홀수가 입력되었다고 출력해준다
 *   5.첫 번째 짝수, 두 번째 홀수가 입력된 경우 두 번째에 홀수가 입력되었다고 출력해준다
 *   6.둘 다 홀수인 경우 두 수 모두 홀수가 입력되었다고 출력해준다
 *  
 *   
 *     
 *   
 */

import java.util.Scanner;

public class Selected_Test2 {

	public static void main(String[] args) {

		Scanner stdIn = new Scanner(System.in);
		
		System.out.print("첫 번째 수를 입력하세요: ");
		int num1 = stdIn.nextInt();
		
		System.out.print("두 번째 수를 입력하세요: ");
		int num2 = stdIn.nextInt();
		
		if(num1%2 == 0 && num2%2 ==0) {
			System.out.println("두 수의 합은:" + (num1 + num2));
		}
			else if(num1%2 !=0 && num2%2 ==0) {
				System.out.println("첫 번째 수가 짝수가 아닙니다");
			}
			else if(num2%2 !=0 && num1%2 ==0) {
				System.out.println("두 번째 수가 짝수가 아닙니다");
			}
			else if(num1%2 !=0 && num2%2 !=0) {
				System.out.println("두 수 모두 짝수가 아닙니다");
		}
		System.out.println("수고하셨습니다");
		
	}

}
