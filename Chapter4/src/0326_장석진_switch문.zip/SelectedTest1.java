/*
 *  세 자리의 십진수를 입력받아 각자리의 숫자들이 짝수인지 홀수인지 판단/
 *  
 *  [문제분석]
 *    짝수는 2로 나눈 나머지가 0.
 *    홀수는 2로 나눈 나머지가 0이 아님.(1이다)
 *    세자리 수는 100~999까지이다.
 *    나머지 수가 오면 오류.
 *    예를 들어 123입력했을 때 100의 자리는 1, 10의 자리는 2, 1의 자리는 3이다.
 *    이때 100의 자리는 홀수, 10의 자리는 짝수, 1의 자리는 홀수가 출력되게 끔 한다.
 *    
 *    100의 자리, 10의 자리, 1의 자리를 구분한다.
 *    힌트) 나누기와 나머지 연산자를 활용한다.
 *    
 *  [알고리즘]
 *     1. 
 *     2.
 *     3.
 *  
 */

import java.util.Scanner;

public class SelectedTest1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
	
		System.out.print("세자리를 입력하세요: ");
		int num = stdIn.nextInt();
		
		if(num >= 100 && num <= 999) {
			int A = num/100; // 100의 자리 몫 찾기
			int B = (num%100) / 10; // 10의 자리 몫 찾기
			int C = (num%100) % 10; // 1의 자리 몫 찾기
		
			
			if(A%2 == 0) {
				System.out.println(A + "는 짝수입니다.");
			}
			else {
				System.out.println(A + "는 홀수입니다.");
			}
			if(B%2 == 0) {
				System.out.println(B + "는 짝수입니다.");
			}
			else {
				System.out.println(B + "는 홀수입니다.");
			}
			if(C%2 == 0) {
				System.out.println(C + "는 짝수입니다.");
			}
			else {
				System.out.println(C + "는 홀수입니다.");
			}
		}
		else {
			System.out.println("잘못된 입력");
			
					
		}
		

	}

}
