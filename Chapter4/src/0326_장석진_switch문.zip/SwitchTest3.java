/*
 * 작성일 : 2024년 3월 26일
 * 작성자 : 202295037 장석진
 * 설명 : 조건식 연습.
 *      숫자와 연산자를 입력 받아
 *      사칙연산 프로그램을 작성하시오.
 *      입력방식 : 3 + 4 (띄어쓰기로 구분)
 * 
 * 문제분석 및 알고리즘
 *     숫자 연산자 숫자를 입력 받아
 *     해당 연산자에 따른 결과를 출력한다.
 *     나눗셈의 결과는 소수자리가 나온다.
 *     소수 2자리까지 출력한다.
 *     
 *     나누기 할 때는 0으로 나눌 수 없다.
 *     두번째 수가 0이면
 *     "나눌 수 없습니다." 출력하자.
 *          
 */

import java.util.Scanner;

public class SwitchTest3 {

    public static void main(String[] args) {
        Scanner stdIn = new Scanner(System.in);
        
       System.out.print("연산 입력(3 + 5): ");
       int num = stdIn.nextInt();
       char ch = stdIn.next().charAt(0);
       int num2 = stdIn.nextInt();
       
       switch(ch) {
       case '+' :
    	   System.out.println(num + "+" + num2 + "=" + (num+num2)); break;
       case '-' :
    	   System.out.println(num + "-" + num2 + "=" + (num-num2)); break;
       case '*' :
    	   System.out.println(num + "*" + num2 + "=" + (num*num2)); break;
       case '/' :
    	   if(num2 == 0) {
    		   System.out.println("계산 할 수 없습니다."); break;
    	   }
    	   else {
    	   System.out.println(num + "/" + num2 + "=" + (num/num2)); break;
       }
    }
}
}

       