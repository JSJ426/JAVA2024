/* 작성일 : 4월 2일
 * 작성자 : 202295037 장석진
 * 
 * 정수를 입력하시오 : 5
 * ★
 * ★★
 * ★★★
 * ★★★★
 * ★★★★★
 */

import java.util.Scanner;

public class nestedLoopTest02 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		System.out.print("입력");
		int num = stdIn.nextInt();
		int i;
		int a;
		
		for(i = 1; i <= num; i++) { //줄
			System.out.print("★");
			for(a = 1; a <= i; a++)  //칸?
			}
	}

}
