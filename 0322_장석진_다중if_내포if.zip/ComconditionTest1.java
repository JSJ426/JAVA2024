/*
 * 작성일 : 2024년 3월 22일
 * 작성자 : 202295037 장석진
 * 설명 : 조건식 연습.
 *      월을 입력받아 해당 계절을 출력하시오.
 *      3, 4, 5월 => 봄
 *      6, 7, 8월 => 여름
 *      9, 10, 11월 => 가을
 *      12, 1, 2월 => 겨울
 * 
 * 문제분석: 입력받아야 할 값은 1~12이다.
 *          0이나 13을 입력하면? => 해당 월은 없습니다 출력
 *          
 * 알고리즘 : 1. 정수를 입력 받는다.
 *         2. 입력된 값이 12~1?, 3~5? 6~8? 9~11?인지 확인
 *         3. 출력
 *         4. else 해당 월은 없음
 */

import java.util.Scanner;

public class ComconditionTest1 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		System.out.println("월을 입력하세요: ");
		int Num = stdIn.nextInt();
		
		if(Num >= 3 && Num <= 5) {
			System.out.println("봄입니다.");
		}
		else if(Num >= 6 && Num <= 8) {
			System.out.println("여름입니다.");
		}
		else if(Num >= 9 && Num <= 11) {
			System.out.println("가을입니다.");
		}
		else if(Num < 12 && Num <= 2 && Num >0) {
			System.out.println("겨울입니다.");
		}
		else
			System.out.println("해당 월은 없습니다.");
			

	}

}
