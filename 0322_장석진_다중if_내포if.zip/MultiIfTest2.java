/*
 * 작성일 : 2024년 3월 19일
 * 작성자 : 202295037 장석진
 * 설명 : 다중 if문 실습
 *       점수를 입력받아 학점을 출력하시오.
 * 
 * 문제 분석 : 90점 이상이면 A학점.
 *          80점 이상이면 B학점.
 *          70점 이상이면 C학점.
 *          60점 이상이면 D학점.
 *          60점 미만이면 F학점.
 *          점수는 정수르 입력 받는다.
 *          
 * 알고리즘 : 1. 점수(정수)를 입력 받는다.
 *         2. 점수가 90점 이상인가?
 *            2-1. A학점입니다. 출력
 *         3. 아니면, 점수가 80점 이상인가?
 *            3-1. B학점입니다. 출력
 *                .
 *                .
 *                .
 *                .
 *          4. 아니면(나머지는)
 *            "프로그램 종료"
 *            
 */

import java.util.Scanner;

	
public class MultiIfTest2 {

	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		// 1. 정수를 입력 받는다

		System.out.print("정수 입력: ");
		int score = stdIn.nextInt();
		
		// 2. 90점 이상입니까? 맞으면 출력
		if(score >= 90  && score <= 100) {
			System.out.println(score + "은(는) A학점 입니다.");
		}
		
		// 3. 80점 이상입니까?
		else if(score >= 80 && score < 90) {
			System.out.println(score + "은(는) B학점 입니다.");
		}
		
		// 4. 70점 이상입니까?
		else if(score >= 70 && score < 80) {
			System.out.println(score + "은(는) C학점 입니다.");
		}
		
		//5. 60점 이상입니까?
		else if(score >= 60 && score < 70) {
			System.out.println(score + "은(는) D학점 입니다.");
		}
			
		// 6. 아니면(나머지는)
		else if(score >= 0 && score < 60){
			System.out.println("60점 미만은 F학점 입니다");		
		}
		else {
			System.out.println("잘못된 점수 입력입니다.");
		}
		
		System.out.println("프로그램 종료");

	}


}