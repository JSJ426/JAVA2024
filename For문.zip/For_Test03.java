/*
 * 작성일 : 4월 5일
 * 작성자 : 202295037 장석진
 *
 *정수를 입력받아 그 수의 약수를 출력하시오.
 *
 *[문제분석]
 * 약수는..(1부터 자신까지 나누었을 때 0이 되는 수)
 * 1부터 입력 받은 수까지 반복하면서
 * 0으로 나누어 나머지가 0이 되는지 판단한다.
 * 1은 수로 나누어 나머지가 0인가?
 * 2는 수로 나누어 나머지가 0인가?
 * 3은 수로 나누어 나머지가 0인가?
 *    .
 *    .
 *    .
 * 23은 수로 나누어 나머지가 0인가?
 *
 *[알고리즘]
 * 1.어떤 수를 입력 받는다.
 * 2.1부터 입력 받은 수까지 1씩 증가하면서 반복
 *   2-1 입력받은 수를 수로 나누어 나머지가 0이면
 *     2-1-1 그 수를 출력한다.
 *
 */

import java.util.Scanner;

public class For_Test03{
	
	public static void main(String[] args) {
		Scanner stdIn = new Scanner(System.in);
		
		
		/*
		System.out.println("수 입력");
		int num = stdIn.nextInt();
		int i;
		
		for(i = 1; i <= num; i++) {
			if(num%i == 0) {
				System.out.print("이 수의 약수는 " + i);
			}
		
		for문으로 작성한 코드
	    */
		
		System.out.println("수 입력");
		int num = stdIn.nextInt();
		int i = 1;
		
		while(i <= num) {
			if(num%i == 0) {
				System.out.print(i + " ");
			}
			i++;
		}
		
	}
}